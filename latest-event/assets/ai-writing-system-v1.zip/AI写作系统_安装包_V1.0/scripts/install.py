#!/usr/bin/env python3
"""Install or reconnect the persistent AI writing system and its Codex skill."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent.parent
TEMPLATE_ROOT = PACKAGE_ROOT / "assets" / "project-template"
SKILL_NAME = "ai-writing-system"
PROJECT_MARKERS = ["AGENTS.md", "PROJECT_INSTRUCTIONS.md", "数据/系统状态.json"]


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def default_skill_dir() -> Path:
    configured = os.environ.get("CODEX_HOME")
    codex_root = Path(configured).expanduser() if configured else Path.home() / ".codex"
    return codex_root / "skills" / SKILL_NAME


def is_system_project(path: Path) -> bool:
    return all((path / marker).is_file() for marker in PROJECT_MARKERS)


def ensure_template() -> None:
    if not is_system_project(TEMPLATE_ROOT):
        raise SystemExit("Installer package is incomplete: project template markers are missing.")


def copy_new_project(target: Path) -> None:
    ensure_template()
    if target.exists():
        if is_system_project(target):
            raise SystemExit(
                "A writing system already exists at the destination. "
                "Use --existing-project to reconnect without copying."
            )
        if any(target.iterdir()):
            raise SystemExit(
                "Destination exists and is not empty. Choose a new directory; "
                "the installer will not overwrite it."
            )
        for item in TEMPLATE_ROOT.iterdir():
            destination = target / item.name
            if item.is_dir():
                shutil.copytree(item, destination)
            else:
                shutil.copy2(item, destination)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(TEMPLATE_ROOT, target)


def validate_existing(target: Path) -> None:
    if not target.is_dir():
        raise SystemExit(f"Existing project directory not found: {target}")
    if not is_system_project(target):
        raise SystemExit(
            "The selected directory is not a valid writing system. "
            "Required marker files are missing."
        )


def install_skill(skill_dir: Path, project_root: Path) -> None:
    if skill_dir.exists():
        existing_entry = skill_dir / "SKILL.md"
        if existing_entry.exists():
            text = existing_entry.read_text(encoding="utf-8", errors="replace")
            if "name: ai-writing-system" not in text:
                raise SystemExit(
                    f"Skill destination belongs to a different skill: {skill_dir}"
                )
        elif any(skill_dir.iterdir()):
            raise SystemExit(
                f"Skill destination is non-empty and unrecognized: {skill_dir}"
            )
    skill_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(PACKAGE_ROOT / "SKILL.md", skill_dir / "SKILL.md")
    shutil.copy2(PACKAGE_ROOT / "安装说明.md", skill_dir / "安装说明.md")
    shutil.copy2(PACKAGE_ROOT / "首次安装提示词.md", skill_dir / "首次安装提示词.md")
    scripts_target = skill_dir / "scripts"
    scripts_target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(__file__).resolve(), scripts_target / "install.py")
    assets_target = skill_dir / "assets" / "project-template"
    if not assets_target.exists():
        assets_target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(TEMPLATE_ROOT, assets_target)
    config = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "project_root": str(project_root),
        "installed_at": now(),
    }
    (skill_dir / "config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def save_install_info(project_root: Path, skill_dir: Path) -> None:
    info = {
        "schema_version": 1,
        "project_root": str(project_root),
        "skill_name": SKILL_NAME,
        "skill_dir": str(skill_dir),
        "installed_at": now(),
        "daily_invocation": "使用 $ai-writing-system 写下一篇。",
    }
    path = project_root / "数据" / "安装信息.json"
    path.write_text(
        json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def run_doctor(project_root: Path) -> None:
    command = [sys.executable, str(project_root / "scripts" / "system.py"), "doctor"]
    result = subprocess.run(command, cwd=project_root, text=True, capture_output=True)
    if result.returncode != 0:
        details = (result.stdout + result.stderr).strip()
        raise SystemExit(f"Project was copied but validation failed:\n{details}")
    print(result.stdout.strip())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Install or reconnect a persistent AI writing system."
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--project-dir",
        help="New project directory. Defaults to ./AI写作系统.",
    )
    group.add_argument(
        "--existing-project",
        help="Existing writing-system directory to reconnect without copying.",
    )
    parser.add_argument(
        "--skill-dir",
        help="Exact skill installation directory. Defaults to the local Codex skills directory.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.existing_project:
        project_root = Path(args.existing_project).expanduser().resolve()
        validate_existing(project_root)
        mode = "reconnected"
    else:
        raw_target = args.project_dir or str(Path.cwd() / "AI写作系统")
        project_root = Path(raw_target).expanduser().resolve()
        copy_new_project(project_root)
        mode = "installed"
    skill_dir = (
        Path(args.skill_dir).expanduser().resolve()
        if args.skill_dir
        else default_skill_dir().resolve()
    )
    install_skill(skill_dir, project_root)
    save_install_info(project_root, skill_dir)
    run_doctor(project_root)
    print(f"Writing system {mode}: {project_root}")
    print(f"Skill installed: {skill_dir}")
    print("Next: 使用 $ai-writing-system 写下一篇。")


if __name__ == "__main__":
    main()

