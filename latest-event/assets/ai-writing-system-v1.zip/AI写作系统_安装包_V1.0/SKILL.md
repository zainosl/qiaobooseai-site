---
name: ai-writing-system
description: Install, initialize, and operate a persistent local AI writing system. Use when the user wants to write, revise, title, research, review, continue, or manage work through their installed writing-system project.
---

# AI Writing System

This skill is the stable entry point to a persistent writing-system project. The skill stores no author data itself; it reads and writes the configured project directory.

## Resolve the project

The installed skill directory must contain `config.json` with:

```json
{"project_root": "/absolute/path/to/AI写作系统"}
```

Read that file first. Resolve `project_root`, then verify these files exist:

- `AGENTS.md`
- `PROJECT_INSTRUCTIONS.md`
- `系统状态.md`
- `数据/系统状态.json`

If the configuration is missing, the path no longer exists, or the markers are absent, do not invent a new system or silently switch directories. Tell the user the connection is missing and use this package's `安装说明.md` to install or reconnect it.

## Start each request

1. Read the project's `AGENTS.md`, `PROJECT_INSTRUCTIONS.md`, and `系统状态.md`.
2. Determine whether to continue the current task or create a new task from the user's wording.
3. Load only the documents required by the routing table in `PROJECT_INSTRUCTIONS.md`.
4. Treat the current user request as higher priority than defaults, while preserving confirmed facts and explicit scope.

Do not ask the user to open the project directory or re-upload the system when the configured project is accessible.

## Persist the work

Use the project as the source of truth:

- Create formal tasks in `任务/`.
- Save materials, briefs, draft versions, author feedback, confirmations, checks, final delivery, and next steps.
- Update `数据/系统状态.json` and `系统状态.md` through `python3 scripts/system.py` when command execution is available.
- If command execution is unavailable but project files are writable, make equivalent file updates directly.
- If neither commands nor project writes are available, clearly state that persistence is unavailable in this environment and output the exact files that need to be saved back. Never claim permanent memory.

Before ending a completed task, ensure important decisions are in project files rather than only in conversation history.

## Boundaries

- Do not fabricate author experiences, audience evidence, customer cases, data, outcomes, or confirmation.
- A writing request does not authorize external upload or publication.
- Local revision does not authorize rewriting confirmed sections outside scope.
- Ordinary task feedback does not automatically change permanent system rules; route proposed changes through `校准/待确认更新.md`.
- Do not expose or copy private project materials into shared templates.

## Installation and reconnection

When the user explicitly asks to install this package, follow `安装说明.md`. Run `scripts/install.py` with the chosen project destination. The installer creates the project, copies this skill into the local Codex skill directory, and writes `config.json`.

When reconnecting to an existing project, validate the marker files and use `--existing-project`. Never overwrite an existing non-system directory.

