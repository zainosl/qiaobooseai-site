#!/usr/bin/env python3
"""Local state helper for the portable AI writing system.

Uses only the Python standard library. It records state; it does not generate
content, call a model, upload drafts, or publish anything.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
TASKS_DIR = ROOT / "任务"
TEMPLATE_DIR = TASKS_DIR / "_模板"
STATE_PATH = ROOT / "数据" / "系统状态.json"
STATUS_MD = ROOT / "系统状态.md"
CORE_FILES = [
    "AGENTS.md",
    "PROJECT_INSTRUCTIONS.md",
    "从这里开始.md",
    "系统状态.md",
    "作者资料.md",
    "业务与读者.md",
    "写作标准.md",
    "工作流.md",
    "研究与反馈.md",
    "交付与确认.md",
    "资料索引.md",
    "数据/系统状态.json",
    "任务/_模板/任务.md",
    "任务/_模板/状态.json",
]


def today() -> str:
    return datetime.now().astimezone().date().isoformat()


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SystemExit(f"Missing file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Invalid JSON in {path}: {exc}") from exc


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def safe_name(value: str) -> str:
    cleaned = re.sub(r"[\\/:*?\"<>|\s]+", "_", value.strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("._")
    if not cleaned:
        raise SystemExit("Task name cannot be empty.")
    return cleaned[:60]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_system_state() -> dict:
    return read_json(STATE_PATH)


def save_system_state(state: dict) -> None:
    state["last_updated"] = today()
    write_json(STATE_PATH, state)
    sync_status_markdown(state)


def sync_status_markdown(state: dict) -> None:
    current = state.get("current_task") or "无"
    initialized = "已完成" if state.get("initialized") else "待完成"
    author = "已初始化" if state.get("initialized") else "待初始化"
    lines = [
        "# 系统状态",
        "",
        f"- 系统版本：V{state.get('system_version', '1.0')}",
        f"- 初始化状态：{initialized}",
        f"- 当前任务：{current}",
        f"- 作者资料：{author}",
        f"- 业务与读者：{author}",
        "- 写作标准：通用初始版；个性化规则见 `校准/已确认规则.md`",
        f"- 待确认系统更新：{state.get('pending_updates', 0)}",
        f"- 已完成真实任务：{state.get('completed_task_count', 0)}",
        f"- 最近更新：{state.get('last_updated', today())}",
        "",
        "## 任务索引",
        "",
        "| 任务 ID | 名称 | 模式 | 状态 | 更新日期 |",
        "|---|---|---|---|---|",
    ]
    for task in state.get("tasks", []):
        lines.append(
            f"| {task.get('id', '')} | {task.get('name', '')} | "
            f"{task.get('mode', '')} | {task.get('status', '')} | "
            f"{task.get('updated_at', '')[:10]} |"
        )
    if not state.get("tasks"):
        lines.append("| — | 暂无任务 | — | — | — |")
    lines.extend(
        [
            "",
            "## 下一步",
            "",
            (
                "完成作者资料与业务读者初始化。"
                if not state.get("initialized")
                else "继续当前任务，或创建下一项真实写作任务。"
            ),
            "",
            "## 说明",
            "",
            "本页由 `scripts/system.py` 同步生成；机器状态以 "
            "`数据/系统状态.json` 为准。",
            "",
        ]
    )
    STATUS_MD.write_text("\n".join(lines), encoding="utf-8")


def task_dir_from_arg(task_arg: str | None) -> Path:
    state = load_system_state()
    task_id = task_arg or state.get("current_task")
    if not task_id:
        raise SystemExit("No task selected and there is no current task.")
    direct = TASKS_DIR / task_id
    if direct.is_dir():
        return direct
    matches = [p for p in TASKS_DIR.iterdir() if p.is_dir() and p.name != "_模板" and p.name.startswith(task_id)]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise SystemExit(f"Task not found: {task_id}")
    raise SystemExit(f"Task id is ambiguous: {task_id}")


def load_task(task_dir: Path) -> tuple[Path, dict]:
    path = task_dir / "状态.json"
    return path, read_json(path)


def save_task(task_dir: Path, task: dict) -> None:
    task["updated_at"] = now()
    write_json(task_dir / "状态.json", task)
    state = load_system_state()
    for item in state.get("tasks", []):
        if item.get("id") == task.get("task_id"):
            item["status"] = task.get("status")
            item["updated_at"] = task.get("updated_at")
            break
    save_system_state(state)


def cmd_new(args: argparse.Namespace) -> None:
    state = load_system_state()
    slug = safe_name(args.name)
    task_id = f"{today()}_{slug}"
    target = TASKS_DIR / task_id
    if target.exists():
        raise SystemExit(f"Task already exists: {target.relative_to(ROOT)}")
    shutil.copytree(TEMPLATE_DIR, target)
    task_path, task = load_task(target)
    created = now()
    task.update(
        {
            "task_id": task_id,
            "name": args.name.strip(),
            "mode": args.mode,
            "status": "active",
            "created_at": created,
            "updated_at": created,
        }
    )
    write_json(task_path, task)
    record_md = target / "任务.md"
    text = record_md.read_text(encoding="utf-8")
    text = text.replace("- 任务名称：", f"- 任务名称：{args.name.strip()}", 1)
    text = text.replace("- 创建日期：", f"- 创建日期：{today()}", 1)
    text = text.replace(
        "- 模式：writing / revise / title / research / retro / delivery",
        f"- 模式：{args.mode}",
        1,
    )
    record_md.write_text(text, encoding="utf-8")
    state.setdefault("tasks", []).append(
        {
            "id": task_id,
            "name": args.name.strip(),
            "mode": args.mode,
            "status": "active",
            "created_at": created,
            "updated_at": created,
        }
    )
    state["task_count"] = len(state["tasks"])
    state["current_task"] = task_id
    save_system_state(state)
    print(target.relative_to(ROOT))


def cmd_event(args: argparse.Namespace) -> None:
    task_dir = task_dir_from_arg(args.task)
    _, task = load_task(task_dir)
    task.setdefault("events", []).append(
        {"at": now(), "type": args.type, "text": args.text}
    )
    save_task(task_dir, task)
    print(f"Recorded {args.type} event in {task_dir.name}.")


def cmd_confirm(args: argparse.Namespace) -> None:
    task_dir = task_dir_from_arg(args.task)
    _, task = load_task(task_dir)
    task.setdefault("confirmations", []).append(
        {
            "at": now(),
            "artifact": args.artifact,
            "scope": args.scope,
            "quote": args.quote,
        }
    )
    save_task(task_dir, task)
    print(f"Recorded confirmation for {args.artifact}.")


def resolve_artifact(task_dir: Path, value: str | None) -> Path | None:
    if not value:
        return None
    candidate = Path(value)
    if not candidate.is_absolute():
        task_candidate = task_dir / candidate
        root_candidate = ROOT / candidate
        candidate = task_candidate if task_candidate.exists() else root_candidate
    candidate = candidate.resolve()
    if not candidate.is_file():
        raise SystemExit(f"Artifact not found: {value}")
    try:
        candidate.relative_to(ROOT)
    except ValueError as exc:
        raise SystemExit("Artifact must be inside the writing-system project.") from exc
    return candidate


def cmd_gate(args: argparse.Namespace) -> None:
    task_dir = task_dir_from_arg(args.task)
    _, task = load_task(task_dir)
    artifact = resolve_artifact(task_dir, args.artifact)
    artifact_rel = str(artifact.relative_to(ROOT)) if artifact else None
    task.setdefault("gates", {})[args.gate] = {
        "decision": args.decision,
        "artifact": artifact_rel,
        "sha256": sha256(artifact) if artifact else None,
        "evidence": args.evidence,
        "checked_at": now(),
    }
    save_task(task_dir, task)
    print(f"Recorded {args.gate} gate: {args.decision}.")


def check_task(task_dir: Path, require_visual: bool = False) -> list[str]:
    _, task = load_task(task_dir)
    problems: list[str] = []
    required = ["problem", "title", "delivery"]
    if require_visual:
        required.append("visual")
    for gate in required:
        value = task.get("gates", {}).get(gate, {})
        allowed = {"pass"} if gate != "visual" or require_visual else {"pass", "not_applicable"}
        if value.get("decision") not in allowed:
            problems.append(f"gate {gate} is {value.get('decision', 'missing')}")
            continue
        artifact = value.get("artifact")
        expected = value.get("sha256")
        if artifact and expected:
            path = ROOT / artifact
            if not path.is_file():
                problems.append(f"gate {gate} artifact is missing: {artifact}")
            elif sha256(path) != expected:
                problems.append(f"gate {gate} is stale because {artifact} changed")
    if task.get("mode") == "writing" and not task.get("confirmations"):
        problems.append("no author confirmation or explicit bypass is recorded")
    return problems


def cmd_check(args: argparse.Namespace) -> None:
    task_dir = task_dir_from_arg(args.task)
    problems = check_task(task_dir, args.visual)
    if problems:
        print("NOT READY")
        for problem in problems:
            print(f"- {problem}")
        raise SystemExit(1)
    print("READY")


def cmd_close(args: argparse.Namespace) -> None:
    task_dir = task_dir_from_arg(args.task)
    problems = check_task(task_dir, args.visual)
    if problems and not args.force:
        print("Cannot close task:")
        for problem in problems:
            print(f"- {problem}")
        raise SystemExit(1)
    _, task = load_task(task_dir)
    artifact = resolve_artifact(task_dir, args.final) if args.final else None
    task["status"] = "completed"
    task["delivery_status"] = args.delivery_status
    task["final_artifact"] = str(artifact.relative_to(ROOT)) if artifact else None
    task.setdefault("events", []).append(
        {"at": now(), "type": "closed", "text": args.note or "Task completed."}
    )
    save_task(task_dir, task)
    state = load_system_state()
    state["completed_task_count"] = sum(
        1 for item in state.get("tasks", []) if item.get("status") == "completed"
    )
    if state.get("current_task") == task.get("task_id"):
        state["current_task"] = None
    save_system_state(state)
    print(f"Closed {task_dir.name}.")


def cmd_init(args: argparse.Namespace) -> None:
    state = load_system_state()
    state["initialized"] = True
    save_system_state(state)
    print("System marked initialized.")


def cmd_status(args: argparse.Namespace) -> None:
    state = load_system_state()
    print(json.dumps(state, ensure_ascii=False, indent=2))


def cmd_doctor(args: argparse.Namespace) -> None:
    problems: list[str] = []
    for relative in CORE_FILES:
        if not (ROOT / relative).is_file():
            problems.append(f"missing core file: {relative}")
    try:
        state = load_system_state()
    except SystemExit as exc:
        problems.append(str(exc))
        state = {"tasks": []}
    for item in state.get("tasks", []):
        task_dir = TASKS_DIR / item.get("id", "")
        if not (task_dir / "状态.json").is_file():
            problems.append(f"missing task state: {item.get('id')}")
            continue
        try:
            read_json(task_dir / "状态.json")
        except SystemExit as exc:
            problems.append(str(exc))
    if problems:
        print("PROJECT INVALID")
        for problem in problems:
            print(f"- {problem}")
        raise SystemExit(1)
    print("PROJECT OK")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Maintain writing-system task state.")
    sub = parser.add_subparsers(dest="command", required=True)

    new_parser = sub.add_parser("new", help="Create a task from the template.")
    new_parser.add_argument("name")
    new_parser.add_argument(
        "--mode",
        choices=["writing", "revise", "title", "research", "retro", "delivery"],
        default="writing",
    )
    new_parser.set_defaults(func=cmd_new)

    event_parser = sub.add_parser("event", help="Record a task event.")
    event_parser.add_argument("--task")
    event_parser.add_argument("--type", required=True)
    event_parser.add_argument("--text", required=True)
    event_parser.set_defaults(func=cmd_event)

    confirm_parser = sub.add_parser("confirm", help="Record author confirmation or bypass.")
    confirm_parser.add_argument("--task")
    confirm_parser.add_argument("--artifact", required=True)
    confirm_parser.add_argument("--scope", required=True)
    confirm_parser.add_argument("--quote", required=True)
    confirm_parser.set_defaults(func=cmd_confirm)

    gate_parser = sub.add_parser("gate", help="Record an execution check.")
    gate_parser.add_argument("--task")
    gate_parser.add_argument(
        "--gate", choices=["problem", "title", "visual", "delivery"], required=True
    )
    gate_parser.add_argument(
        "--decision", choices=["pass", "revise", "not_applicable"], required=True
    )
    gate_parser.add_argument("--artifact")
    gate_parser.add_argument("--evidence", required=True)
    gate_parser.set_defaults(func=cmd_gate)

    check_parser = sub.add_parser("check", help="Check whether a task is ready.")
    check_parser.add_argument("--task")
    check_parser.add_argument("--visual", action="store_true")
    check_parser.set_defaults(func=cmd_check)

    close_parser = sub.add_parser("close", help="Close a completed task.")
    close_parser.add_argument("--task")
    close_parser.add_argument("--final")
    close_parser.add_argument(
        "--delivery-status",
        choices=["local_only", "sent", "draft_uploaded", "published"],
        default="local_only",
    )
    close_parser.add_argument("--note")
    close_parser.add_argument("--visual", action="store_true")
    close_parser.add_argument("--force", action="store_true")
    close_parser.set_defaults(func=cmd_close)

    init_parser = sub.add_parser("init", help="Mark author and business setup complete.")
    init_parser.set_defaults(func=cmd_init)

    status_parser = sub.add_parser("status", help="Print system state.")
    status_parser.set_defaults(func=cmd_status)

    doctor_parser = sub.add_parser("doctor", help="Validate project structure and JSON.")
    doctor_parser.set_defaults(func=cmd_doctor)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

